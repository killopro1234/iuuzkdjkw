Plantilla del código C34
